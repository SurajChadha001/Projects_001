pip install pandas
pip install matplotlib
pip install seaborn